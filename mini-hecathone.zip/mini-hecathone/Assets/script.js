alert();

const cart = [];

document.querySelectorAll('.shop-now').forEach(button => {
  button.addEventListener('click', (event) => {
    const productElement = event.target.closest('.product');
    const productName = productElement.dataset.name;
    const productPrice = parseFloat(productElement.dataset.price);

    const existingProduct = cart.find(item => item.name === productName);
    if (existingProduct) {
      existingProduct.quantity += 1;
    } else {
      cart.push({ name: productName, price: productPrice, quantity: 1 });
    }

    updateCart();
  });
});

function updateCart() {
  const cartItemsElement = document.querySelector('#cart-items tbody');
  cartItemsElement.innerHTML = '';

  let subtotal = 0;
  cart.forEach(item => {
    const row = document.createElement('tr');

    row.innerHTML = `
      <td>${item.name}</td>
      <td>
        <button class="decrease">-</button>
        ${item.quantity}
        <button class="increase">+</button>
      </td>
      <td>$${(item.price * item.quantity).toFixed(2)}</td>
      <td><button class="remove">Remove</button></td>
    `;

    row.querySelector('.increase').addEventListener('click', () => {
      item.quantity += 1;
      updateCart();
    });

    row.querySelector('.decrease').addEventListener('click', () => {
      if (item.quantity > 1) {
        item.quantity -= 1;
      } else {
        cart.splice(cart.indexOf(item), 1);
      }
      updateCart();
    });

    row.querySelector('.remove').addEventListener('click', () => {
      cart.splice(cart.indexOf(item), 1);
      updateCart();
    });

    cartItemsElement.appendChild(row);
    subtotal += item.price * item.quantity;
  });

  const discount = subtotal > 200 ? 20 : 0;
  const total = subtotal - discount;

  document.querySelector('#subtotal').textContent = subtotal.toFixed(2);
  document.querySelector('#discount').textContent = discount.toFixed(2);
  document.querySelector('#total').textContent = total.toFixed(2);
  document.querySelector('#cart-count').textContent = cart.length;
  document.querySelector('.cart-details').style.display = cart.length ? 'block' : 'none';
}